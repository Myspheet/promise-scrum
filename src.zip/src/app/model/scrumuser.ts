export class Scrumuser {

  constructor(public email: string, public fullname: string,
              public projectName: string, public password: string,
              public userType: string) { }
}
